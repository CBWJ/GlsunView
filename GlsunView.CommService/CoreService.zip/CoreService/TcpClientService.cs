﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Text.RegularExpressions;

namespace GlsunView.CommService
{
    public class TcpClientService : IDisposable
    {
        public string IP { get; set; }
        public int Port { get; set; }
        public int RecvTimeOut { get; set; }
        public string DataPattern { get; set; }
        /// <summary>
        /// 客户端
        /// </summary>
        private TcpClient _tcpClient;
        /// <summary>
        /// 线程同步事件
        /// </summary>
        private ManualResetEvent _eventRecieve;
        /// <summary>
        /// 接受数据
        /// </summary>
        private StringBuilder _sbRecv;
        /// <summary>
        /// 是否停止接收
        /// </summary>
        private bool _bStop;
        public TcpClientService()
        {
            _tcpClient = new TcpClient();
            _eventRecieve = new ManualResetEvent(false);
            _sbRecv = new StringBuilder();
        }

        public TcpClientService(string ip, int port, int timeout = 100, string pattern = @"^<\S+>$")
        {
            IP = ip;
            Port = port;
            RecvTimeOut = timeout;
            DataPattern = pattern;
            _tcpClient = new TcpClient();
            _eventRecieve = new ManualResetEvent(false);
            _sbRecv = new StringBuilder();
        }

        public void Start()
        {
            _bStop = false;
            //开启一个线程来接受服务器发来的数据
            Task.Factory.StartNew(()=> {
                while (!_bStop)
                {
                    try
                    {
                        if (_tcpClient.Connected)
                        {
                            var recvStream = _tcpClient.GetStream();
                            if (recvStream.CanRead)
                            {
                                byte[] buffer = new byte[2 * 1024];
                                int recvSize = recvStream.Read(buffer, 0, buffer.Length);
                                if (recvSize == 0)
                                    continue;
                                _sbRecv.Append(Encoding.ASCII.GetString(buffer, 0, recvSize));
                                if (Regex.IsMatch(_sbRecv.ToString(), DataPattern))
                                {
                                    //收到正确数据，发送信号，让调用线程不再等待
                                    _eventRecieve.Set();
                                }
                            }
                        }
                    }
                    catch(Exception ex)
                    {
                        //发生异常则通知线程不再等待
                        _sbRecv.Clear();
                        _sbRecv.Append(ex.Message);
                        _eventRecieve.Set();
                        break;
                    }
                }
            });
        }
        public void Stop()
        {
            _bStop = true;
        }

        public void Connect()
        {
            _tcpClient.Connect(IP, Port);
            Start();
        }

        public void Close()
        {
            Stop();
            _tcpClient.Close();
        }

        public string SendRecv(string cmd)
        {
            string ret = "";
            if (_tcpClient.Connected)
            {
                var sendStream = _tcpClient.GetStream();
                var buffer = Encoding.ASCII.GetBytes(cmd);
                if (sendStream.CanWrite)
                {
                    _eventRecieve.Reset();//重置信号
                    _sbRecv.Clear();
                    sendStream.Write(buffer, 0, buffer.Length);
                    //超时内等待信号
                    if (_eventRecieve.WaitOne(RecvTimeOut))
                    {
                        //正常处理
                        ret = _sbRecv.ToString();
                    }
                    else
                    {
                        //超时处理
                        ret = "读取超时";
                    }
                }
            }
            return ret;
        }

        public void Dispose()
        {
            Close();
        }
    }
}
